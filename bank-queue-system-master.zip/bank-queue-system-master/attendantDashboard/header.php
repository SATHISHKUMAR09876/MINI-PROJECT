<html>

<?php 
		include('../connect.php');
?>
<head>
	<title>Bank Queue</title>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="stylesheet" href="../assets/css/main.css" />
</head>
<body class="subpage">
		<header id="header">
				<div class="logo"><a href="index.php"><strong style="font-size: 2em;
				color: #eee" >Bank Queue System</strong></a></div>
				<a href="#menu">Menu</a>
			</header>

				<nav id="menu">
				<ul class="links">
					<li><a href="../index.php ">Home</a></li>
					<li><a href="attendantlogin.php">Attendant Login</a></li>
					<li><a href="callcustomer.php">Call Customer</a></li>
					<li><a href="../onCall.php">Customers on Call</a></li>
				</ul>
			</nav>