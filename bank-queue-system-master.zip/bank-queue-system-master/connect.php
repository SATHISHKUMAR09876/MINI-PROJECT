<?php
 $con = mysqli_connect("localhost","root","");
 mysqli_select_db($con, 'bankq_db') or die(mysqli_error($con));
